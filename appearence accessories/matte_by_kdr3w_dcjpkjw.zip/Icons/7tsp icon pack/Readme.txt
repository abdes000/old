Remove the file extension ".remove" from the file before using.

To install this icon pack you need to use 7TSP GUI 2019 Edition found here:

http://fav.me/ddb5026

Installation:
Run 7TSP GUI, click 'Add a Custom Pack' and browse to the location of 7tsp mattemis and select it.
Click on Start Patching.
By default 7TSP will create a restore point & install the icon pack.
Once installation is done reboot & you're done.

Uninstall:
Run 7TSP GUI, click restore and click Ok on the Restore Menu. 
Once uninstalled, reboot. 

Note:
Do not use any of these icon packs on any other Windows 10 builds other than 1903 and above.

CREDITS TO devillnside and Moonnique for the installer. niivu for the instructions.
