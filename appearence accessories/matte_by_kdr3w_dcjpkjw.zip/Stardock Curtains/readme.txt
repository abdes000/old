DESCRIPTION

Curtains Styles to add matte title bar and caption buttons on modern Windows apps.

HOW TO
1. Install Stardock's Curtains app: https://www.stardock.com/products/curtains/
2. Open the Curtains Styles folder next to this readme file and double click on each Curtains Style that you want to install, which will also open the Curtains Styles panel.
3. Choose the desired matte Curtain Style.
4. For better compatibility, go to Curtains Options > More style settings... and uncheck "Apply style to window title bars"

Credit:
dpcdpc11