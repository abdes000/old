For StartIsBack taskbar and start menu.
Place in your StartIsBack/Styles folder and select from StartIsBack configuration.