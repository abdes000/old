*** DESCRIPTION ***

Theme for Windows 10. Supported builds: 1703, 1709, 1803, 1809, 1903, 1909, 2004 and 2009(20H2).
To determine what build you're on, run 'winver' from the start menu.


*** HOW TO ***

1.Create a system restore point!!! In case your system gets messed up you can restore it.

2.Patch your system using ultraUXThemePatcher:
https://www.syssel.net/hoefs/software_uxtheme.php?lang=en
See FAQ on patcher site if patcher is not working.
OR
https://github.com/namazso/SecureUxTheme

3.Copy contents of the Theme folder to C:\Windows\Resources\Themes.

4.Open Settings > Personalization > Themes. Apply theme.

Themes with 'Office' in the name support office app colors. When using these variants the theme colors won't be applied consistently in some parts. For example the task manager and task dialogues.

Themes with 'NA' in the name have the address bar hidden


*** TWEAKS ***

Install OldNewExplorer to remove the ribbon.
https://msfn.org/board/topic/170375-oldnewexplorer-118/
See image 01 for configuration

Install Blank it for a cleaner address bar
http://fav.me/dbnc5q5

Apply other tweaks using Winaero Tweaker
https://winaero.com/

Use Alt + Shift + P and Alt + P to toggle the details pane and preview pane respectively

Taskbar & Start menu
https://www.startisback.com/

Time and Date
https://github.com/White-Tiger/T-Clock

Instructions for icons and startisback are in their respective folders.


*** WALLS ***

https://imgur.com/lvmGjrA (credit: ItzSheepy)
https://unsplash.com/collections/87509070/matte-theme-wallpapers


*** NOTE ***

If the some of the above instructions don't make sense, check out Youtube for videos on installing custom themes on Windows 10

For dark themes Windows 10 loads defaults from
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\DefaultColors]
after every lock/sleep/hibernate/crash. 
Make a backup of that key, take ownership
(https://winaero.com/comment.php?comment.news.210)
of it, and then delete that whole key (defaultcolors)

Sometimes the patcher may fail to patch your system. Uninstall it and take ownership of the following files in C:\Windows\System32
uxtheme.dll, UXInit.dll and themeui.dll. 
You may use this: https://www.howtogeek.com/howto/windows-vista/add-take-ownership-to-explorer-right-click-menu-in-vista/
Install the patcher again, note status of the files (see image 02).

Apply the  default Windows theme and uninstall patcher before updating to major Windows 10 update e.g updating from 1909 to 2004


*** SUPPORT ***

If you like the theme you may support me by buying it here:
https://gum.co/

Thanks, enjoy!